# Secrets
`MONGO` - enter your mongo URI in the value, don't know how to find mongo URI?, [click me!](https://www.youtube.com/watch?v=A_U_bIhp4t8)
<br>
<BR>
`TOKEN` - enter your bot token in the value, [Discord Developers Portal Applications](https://discord.com/developers/applications)